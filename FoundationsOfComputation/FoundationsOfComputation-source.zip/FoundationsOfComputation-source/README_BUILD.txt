
Note about building the PDF files:

1. Run   latex main6x9.tex   *twice*  to generate the correct table of contents.
2. Run   makeindex main6x9.idx   to generate the index.
3. Run   latex main6x9.tex   *again* to incorporate the index.
4. Run   dvipdf main6x9.dvi   to make the PDF.  The file will be named main6x9.pdf.
 

This builds a 6-by-9 inch PDF.   For the 8.5-by-11 inch PDF, repeat the above, 
replacing   "main6x9"   with  "main"

(Note that latexpdf doesn't handle the EPS graphics files that are used in the book.)


