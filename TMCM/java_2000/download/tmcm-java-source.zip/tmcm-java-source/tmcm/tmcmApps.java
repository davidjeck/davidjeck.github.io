
import tmcm.tmcmAppsFrame;

public class tmcmApps  {

   public static void main(String[] args) {
      new tmcmAppsFrame();
   }
   
}
