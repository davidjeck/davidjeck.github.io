
import tmcm.tmcmLabsFrame;

public class tmcmLabs  {

   public static void main(String[] args) {
      new tmcmLabsFrame();
   }
   
}
