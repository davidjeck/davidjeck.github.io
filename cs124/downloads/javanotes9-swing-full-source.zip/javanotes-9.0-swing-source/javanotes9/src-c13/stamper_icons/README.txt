The icons in this folder are for the sample program
SillyStamper.java.  They were taken from the KDE desktop
icon collection.

