
The playing cards in this folder were downloaded from
the following address on wikimedia commons 29-Oct-2011

http://commons.wikimedia.org/wiki/File:Poker-sm-212-Ks.png

Joker is from

https://commons.wikimedia.org/wiki/Joker#mediaviewer/File:Jolly_Rosso.jpg

I made back.jpg myself.

These images are listed as having been placed by their
author into the public domain.

I reduced the image size by 50% (in each direction) and
converted them from PNG to JPEG, with quality set to 75.

