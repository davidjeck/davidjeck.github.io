Earth-1024x512.jpg is a resized image from
http://maps.jpl.nasa.gov/ (courtesy NASA/JPL-Caltech)
Image can be freely distributed but should credit
the NASA/JPL-Caltec.

brick001.jpg and metal003.gif are from
http://www.grsites.com/archive/textures/
a collection of free background images.

Earth-512x256.jpg is a version of an image
that seems to be all over the Internet. I don't
know its original origin.

